﻿Configuration IISServer
{
  Node $env:COMPUTERNAME
  {
    WindowsFeature WebServer
    {
      Ensure = 'Present'
      Name = 'Web-Server'
    }

    WindowsFeature WebAspNet45
    {
      Ensure = 'Present'
      Name = 'Web-Asp-Net45'
      DependsOn = '[WindowsFeature]WebServer'
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = 'Web-Mgmt-Console'
        Ensure = 'Present'
        DependsOn = '[WindowsFeature]WebServer'
    }
  }
}